
document.getElementById('searchBtn').addEventListener('click', function () {
  const query = document.getElementById('searchInput').value;
  const resultDiv = document.getElementById('searchResults');
  resultDiv.innerHTML = '<p>Searching for: ' + query + '</p>';
});
