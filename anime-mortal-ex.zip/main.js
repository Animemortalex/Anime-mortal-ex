document.addEventListener('DOMContentLoaded', () => {
  const enterBtn = document.getElementById('enter-btn');
  if (enterBtn) enterBtn.addEventListener('click', () => location.href = 'main.html');

  if (!location.pathname.endsWith('main.html')) return;

  const sidebar = document.getElementById('sidebar');
  document.getElementById('menu-btn').addEventListener('click', () => sidebar.classList.toggle('show'));

  const content = document.getElementById('content');
  renderGrid(animeList);

  const searchInput = document.getElementById('search-input');
  const searchBtn = document.getElementById('search-btn');
  searchBtn.addEventListener('click', () => renderSearch(searchInput.value));
  searchInput.addEventListener('keypress', e => { if (e.key === 'Enter') renderSearch(e.target.value); });

  function renderGrid(list) {
    content.innerHTML = '';
    if (!list.length) { content.innerHTML = '<p>No results…</p>'; return; }
    list.forEach(a => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `<img src="${a.image}" alt="${a.title}"><h4>${a.title}</h4>`;
      content.appendChild(card);
    });
  }

  function renderSearch(q) {
    const term = q.trim().toLowerCase();
    if (!term) { renderGrid(animeList); return; }
    renderGrid(animeList.filter(a => a.title.toLowerCase().includes(term)));
  }
});
