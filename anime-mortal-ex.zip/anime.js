const animeList = [
  {title:'Naruto', image:'https://i.imgur.com/7yUvePI.jpg'},
  {title:'One Piece', image:'https://i.imgur.com/pEk5a9J.jpg'},
  {title:'Spirited Away', image:'https://i.imgur.com/MpqECGD.jpg'}
];
